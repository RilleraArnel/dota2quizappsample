<!doctype html>
<html lang="en">
<div style="background-color:orange;">
<head>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Simple Database App</title>

	<link rel="stylesheet" href="css/style.css">
</head>

<div class="container" style="text-align:center; color:red;">
  <div class="jumbotron" style="background-color:yellow;">
    <h1 style="background-color:yellow;">Simple Database App</h1> 
    <p style="background-color:yellow;">A simple Database App that's quite difficult to make.</p> 
  </div>
</div>
