<html>
<head>
	<title></title>
</head>
<body>
	<?php 
		echo "Twinkle, Twinkle little star. <br>";
		$twinkle = "Twinkle";
		$star = "star";
		echo $twinkle .", ". $twinkle . " Little " . $star .".<br>";
		$twinkle = "Twinkie";
		$star = "Bar";
		echo $twinkle .", ". $twinkle . " Little " . $star .".<br>";
	?>
</body>
</html>