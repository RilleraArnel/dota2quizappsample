<html>
<head>
	<title></title>
</head>
<body>
	<?php 
		$x=10;
		$y=7;
		$z;
		$z = $x+$y;
		echo $x . " + " . $y . " = " . $z."<br>";
		$z = $x-$y;
		echo $x . " - " . $y . " = " . $z."<br>";
		$z = $x*$y;
		echo $x . " * " . $y . " = " . $z."<br>";
		$z = $x/$y;
		echo $x . " / " . $y . " = " . $z."<br>";
		$z = $x%$y;
		echo $x . " % " . $y . " = " . $z."<br>";
	?>
</body>
</html>