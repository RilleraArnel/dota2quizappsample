<html>
<p>
<?php 
echo "Sifting through the broken glass<br>
The echoes of my ancient past<br>
Keep flooding into every pore<br>
Like scattered seeds of sycamore<br>
Suddenly I started wondering how I got here<br>
<br>
Was it a matter of time?<br>
<br>
Catholic school my private Hell<br>
I stuttered 'til the age of twelve<br>
Discovered sex at seventeen<br>
And soon thereafter Self Esteem<br>
The days did not matter<br>
And years were a lifetime away<br>
<br>
Drowning in a heavy stock<br>
Of teenage girls and Indie Rock<br>
I flunked out of each college course<br>
And set my sails for no remorse<br>
The nights were for nowhere <br>
And that's where I wanted to be<br>
<br>
Someone said,<br>
It's not a matter of time, it's just a matter of timing<br>
<br>
Do you ever wonder how you got to here?<br>
It's not a matter of time, it's just a matter of timing<br>
Do you ever wonder how you got to here?<br>
<br>
Branded, marked and paper thin<br>
This angry saint went marching in<br>
To war with scores of ninety proof<br>
Found nothing but the ugly truth<br>
The decade of wastage an instant <br>
And everything's changed<br>
<br>
Woke up feeling 35<br>
Though grateful that I'm still alive<br>
Another chance at normalcy<br>
To chase the dream but now it seems<br>
That days run away like wild horses over the hills<br>
<br>
Someone said,<br>
It's not a matter of time, it's just a matter of timing<br>
<br>
Do you ever wonder how you got to here?<br>
It's just a matter of time<br>
It's not a matter of time, it's just a matter of timing<br>
Do you ever wonder how you got to here?<br>
<br>
Take it in and hold on while you can<br>
All the destruction will one day end<br>
And you'll finally know exactly who you are<br>
It's just a matter of timing<br>
<br>
Do you ever wonder how you got to here?<br>
It's just a matter of time<br>
It's not a matter of time, it's just a matter of timing<br>
<br>
Do you ever wonder how you got to here?<br>
It’s just a matter of time<br>
It’s not a matter of time, it’s just a matter of timing<br>
<br>
Do you ever wonder how you got to here?<br>
Do you ever wonder how you got to here?<br>"
?>

</p>
</html>