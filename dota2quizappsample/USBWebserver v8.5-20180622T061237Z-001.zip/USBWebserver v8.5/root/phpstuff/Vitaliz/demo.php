<html> 
<?php 
echo "Hello PHP!";
?>
</html>
