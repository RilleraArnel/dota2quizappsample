<html>
<p>
<?php 
require '/song1.php';
require '/song2.php';
?>
</p>
</html>