<html>
<head>
	<title></title>
</head>
<body>
	<?php 
		$whatsit = "Wassaaap";
		echo "Value is " . gettype($whatsit) . ".<br>";
		$whatsit = 5.55;
		echo "Value is " . gettype($whatsit) . ".<br>";
		$whatsit = false;
		echo "Value is " . gettype($whatsit) . ".<br>";
		$whatsit = 4;
		echo "Value is " . gettype($whatsit) . ".<br>";
		$whatsit = null;
		echo "Value is " . gettype($whatsit) . ".<br>";

	?>
</body>
</html>