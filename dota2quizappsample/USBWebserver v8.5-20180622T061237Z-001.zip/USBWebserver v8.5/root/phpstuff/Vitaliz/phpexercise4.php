<html>
<head>
	<title></title>
</head>
<body>
	<?php 
		$around = 'around';
		echo "What goes ". $around ." comes " . $around . ". <br>";
		echo "What goes $around comes $around.";
	?>
</body>
</html>