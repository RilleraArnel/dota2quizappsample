<html>
<head>
	<title></title>
</head>
<body>
	<?php 
		$value = 8;
		echo "<br> Value us now " . $value;
		echo "<br> Add 2. Value is now " . $value+=2;
		echo "<br> Subtract 4. Value is now " . $value-=4;
		echo "<br> Multiply by 5. Value is now " . $value*=5;
		echo "<br> Divide by 3. Value is now " . $value/=3;
		echo "<br> Increment value by one. Value is now " . ++$value;
		echo "<br> Decrement value by one. Value is now " . --$value;

	?>
</body>
</html>