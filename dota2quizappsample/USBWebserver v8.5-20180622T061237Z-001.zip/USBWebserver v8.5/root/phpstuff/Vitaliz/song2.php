<html>
<p>
<?php 
echo "Time goes by<br>
	And I've been holding everything inside<br>
	But now I've got nothing left to hide<br>
	When I'm with you, oh, you<br>
	But I can see<br>
	How strong a man I'm gonna have to be<br>
	To do for you what comes so naturally<br>
	It's in the way you move<br>
	And all I want<br>
	Is a chance to prove<br>
	Show all I can do<br>
	I believe in starting over<br>
	I can see that your heart is true<br>
	I believe in good things coming back to you<br>
	You're the light that lifts me higher<br>
	So bright, you guide me through<br>
	I believe in you<br>
	And I don't mind<br>
	If you want to hold onto me tight<br>
	You don't have to sleep alone tonight<br>
	If you don't want to<br>
	And all I want<br>
	Is to know you're near<br>
	You're all I need here<br>
	I believe in starting over<br>
	I can see that your heart is true<br>
	I believe in good things coming back to you<br>
	You're the light that lifts me higher<br>
	So bright, you guide me through<br>
	I believe in you<br>
	I know that there are times<br>
	When you feel worthless<br><br>
	Like all the love you get<br>
	You don't deserve it<br>
	Sometimes I feel my faith is just a burden<br>
	On you, you, you<br>
	I believe in starting over<br>
	I can see your heart is true<br>
	I believe in love<br>
	You give me reason to<br>
	You're the light that lifts me higher<br>
	So high up in the sky<br>
	I, I think we're gonna fly<br>
	I believe in starting over<br>
	I can see that your heart is true<br>
	I believe in love<br>
	You give me reason to<br>
	You're the light that lifts me higher<br>
	So bright, you guide me through<br>
	I believe in you<br>
	I believe in you<br>
	I believe in you<br>
	You guide me through<br>
	I believe in you<br>"
?>
</p>
</html>