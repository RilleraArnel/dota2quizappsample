<!doctype html>
<html lang="en">

<head>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Simple Database App</title>

	<link rel="stylesheet" href="css/style.css">
</head>

<div class="container" style="text-align:center; color:blue;">
  <div class="jumbotron" style="background-color:lightblue;">
    <h1 style="background-color:lightblue;">Aqua Forums</h1> 
    <p style="background-color:lightblue;">A Forum about marine life.</p> 
  </div>
</div>
